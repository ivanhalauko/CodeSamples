# Code Samples for .NET Internal Lab Gomel
