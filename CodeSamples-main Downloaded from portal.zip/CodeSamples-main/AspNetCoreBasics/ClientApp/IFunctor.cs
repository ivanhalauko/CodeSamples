﻿namespace ClientApp
{
    public interface IFunctor
    {
        public void DoWork();
    }

    public class Functor : IFunctor
    {
        public void DoWork()
        {
        }

        public void DoWork1()
        {
        }
    }
}
