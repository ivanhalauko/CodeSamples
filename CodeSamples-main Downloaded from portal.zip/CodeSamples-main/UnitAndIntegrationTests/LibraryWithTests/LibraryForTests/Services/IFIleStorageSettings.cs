﻿namespace LibraryForTests.Services
{
    public interface IFIleStorageSettings
    {
        string FileNameData { get; }
    }
}
