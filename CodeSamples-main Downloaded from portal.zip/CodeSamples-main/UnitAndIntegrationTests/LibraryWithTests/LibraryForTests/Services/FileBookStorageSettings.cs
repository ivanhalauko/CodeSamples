﻿using System;

namespace LibraryForTests.Services
{
    class FileBookStorageSettings : IFIleStorageSettings
    {
        ValueType d;
        public string FileNameData => "Books.txt";
    }
}
