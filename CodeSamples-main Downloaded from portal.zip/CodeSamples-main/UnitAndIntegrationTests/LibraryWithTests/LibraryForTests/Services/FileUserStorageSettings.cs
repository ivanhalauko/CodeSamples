﻿namespace LibraryForTests.Services
{
    class FileUserStorageSettings : IFIleStorageSettings
    {
        public string FileNameData => "Users.txt";
    }
}
