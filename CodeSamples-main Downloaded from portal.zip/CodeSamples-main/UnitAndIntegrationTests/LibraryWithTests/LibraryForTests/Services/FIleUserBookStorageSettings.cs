﻿namespace LibraryForTests.Services
{
    class FIleUserBookStorageSettings : IFIleStorageSettings
    {
        public string FileNameData => "UserBooks.txt";
    }
}
