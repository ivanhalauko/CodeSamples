﻿namespace LibraryForTests.Domain
{
    public interface IArchivable
    {
        bool IsArchive { get; set; }
    }
}
