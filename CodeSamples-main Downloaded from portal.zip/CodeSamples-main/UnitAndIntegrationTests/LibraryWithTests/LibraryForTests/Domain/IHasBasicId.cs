﻿namespace LibraryForTests.Domain
{
    public interface IHasBasicId
    {
        int Id { get; set; }
    }
}
