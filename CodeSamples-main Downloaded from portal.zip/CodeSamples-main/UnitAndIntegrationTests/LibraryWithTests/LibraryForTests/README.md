﻿Homework:

Extend functionality of the library application:
- add date assignments during rent process
- implement all not implement services
- add return book function. It should delete record fro UserBook storage
- add book history action. New records which tracks all actions performed in library. (optional)
- all of functionality should be covered by tests unit or integration
